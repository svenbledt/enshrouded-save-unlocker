SAVE UNLOCKER  v0.1.2
Character save editor for Enshrouded (Windows)
================================================

Save Unlocker edits your Enshrouded CHARACTER save (character*.ksd). World saves
are never touched. Every edit stays within what the game itself allows, so the
game loads the result as if you had played it.

What you can do
---------------
- Level and XP (up to the level cap).
- Skill tree: buy/refund ranks like in game, respec, and apply build presets
  (Barbarian sword, Barbarian axe, Archer, Assassin, Healer, Mage). Presets show
  their remaining path on the tree so you can follow them while levelling.
- Elixir Wells and Shroud Roots (skill points), fog of war, item discovery.
- Recipes the character can unlock (world-bound recipes are shown read-only).
- Inventory: backpack, both action bars, equipment, bag, ranged/arrow/spell
  slots, item level/rarity/upgrades/gems, "Repair all".
- Preset gear: fully upgraded, equipped, never duplicated; asks before
  replacing what you wear.

Requirements
------------
- Windows 10/11 (64-bit).
- Enshrouded installed (Steam). The editor reads item names, icons, the skill
  tree and the map from your game installation; it finds it automatically
  (or pick the folder when asked).

How to use
----------
1. Close Enshrouded (the editor refuses to write while the game is running).
2. Start SaveUnlocker.exe. It finds your characters automatically, both Steam
   Cloud saves (wherever Steam is installed) and local saves
   (%USERPROFILE%\Saved Games\keen games\Enshrouded); if you have both, all of
   them are listed. If none show up (saves on another drive or elsewhere), click
   "Choose folder" on the Characters screen and pick the folder that holds your
   character*.ksd files. Your choice is remembered for next time.
3. Pick a character, make your changes, then Save.
4. Start the game and load the character.

Backups
-------
Before every save the previous file is copied to
  %LOCALAPPDATA%\SaveUnlocker\backups\<character name>\
You can restore any backup from the "Save & Backups" screen.

Steam Cloud
-----------
Edit only while the game is closed. If Steam reports a cloud conflict when you
start the game, choose the LOCAL files (those are your edited save).

Uninstall
---------
Delete the SaveUnlocker folder. Optionally delete %LOCALAPPDATA%\SaveUnlocker
(game-data cache and your backups).

Notes
-----
- Every edit has been tested in-game. Still, keep your backups.
- Use at your own risk. Save Unlocker is a fan-made tool and is not affiliated
  with or endorsed by Keen Games. Enshrouded is a trademark of its owner.
- Third-party licenses: see LICENSES\THIRD-PARTY-NOTICES.txt.
